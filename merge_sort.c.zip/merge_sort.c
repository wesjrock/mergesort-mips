#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define MAXSIZE 16                 //tamanho m�ximo de um vetor n�o-ordenado
#define UNITYSIZE 4                //tamanho m�ximo de um subvetor a ser ordenado com bubble_sort

int* MergeSort(int*, int, int);
void vectorCopy(int*, int*);       //fun��o auxiliar de MergeSort
void merge_sort(int*, int, int );
void merge(int*, int, int, int);
void swap(int*, int, int);         //fun��o auxiliar de bubble_sort()
void bubble_sort(int*, int);

//Vetor n�o-ordenado e seu tamanho:
int Vector[MAXSIZE] = {12, 21, 45, 0, 4, 13, 12, 77, 2};
int vectorSize = 8;

//Vetores auxiliares:

int A[MAXSIZE];                       //"A" � o vetor que ser� ordenado.

int L[(int)(ceil(MAXSIZE/2)) + 1];    /*Os vetores "L" e "R" s�o vetores auxiiares usados pela*/
int R[(int)(ceil(MAXSIZE/2)) + 1];    /*fun��o merge na ordena��o de um subvetor de tamanho*/
                                      /*maior que 4 elementos*/

int v[UNITYSIZE];                     /*O vetor v � um vetor auxiliar usado pela fun��o merge*/
                                      /*na ordena��o de um subvetor de tamanho menor ou igual*/
                                      /*a 4 elemntos*/

//r�tulo "main:"
int main()
{
    int i, *orderedVector;
    int p = 0, r = vectorSize - 1;   /* p: �ndice inicial do vetor n�o-ordenado*/
                                     /* r: �ndice final do vetor n�o-ordenado  */
        
    
    //Ordena��o:
    orderedVector = MergeSort(Vector, p, r);

    if(orderedVector)
    {
        //r�tulo "Exibir_Vetores:"

        //Exibi��o do vetor de entrada:
        printf("Entrada:\n\nVector[] = { ");
        for(i = 0; i < vectorSize; i++)
            printf("%i ",Vector[i]);
        printf("}");

        //Exibi��o do vetor de sa�da:
        printf("\n\nSaida:\n\nA[] = { ");
        for(i = 0; i < vectorSize; i++)
            printf("%i ",orderedVector[i]);
        printf("}\n\n");

        return 0;
    }
    else
    {
        //r�tulo "Exibir_TamanhoInvalido:"
        printf("\nA Quantidade de elementos eh invalida");
        return 1;
    }
//r�tulo "fim:"
}

int* MergeSort(int *Vector, int p, int r)
{
    //r�tulo "MergeSort:"
    if((vectorSize < 1)||(vectorSize > MAXSIZE))
    {
        //r�tulo "MergeSort_TamanhoInvalido:"
        return NULL;
    }

    vectorCopy(A, Vector); //c�pia do vetor "Vector" para o vetor "A" que ser� ordenado.
    merge_sort(A, p, r);

    //r�tulo "MergeSort_Fim:"
    return A;
}

void vectorCopy(int *A, int *Vector)
{
    //r�tulo "VectorCopy:"
    int i;

    for(i = 0; i < vectorSize; i++)
        //r�tulo "VectorCopy_Loop:"
        A[i] = Vector[i];

    //r�tulo "VectorCopy_Fim:"
}

void merge_sort(int *A, int p, int r)
{
    //r�tulo "merge_sort:"
    int q;

    if(p < r)
    {
        //r�tulo "merge_sort_inicio:"
        q = floor((p + r)/2);
        if((r - p + 1) > UNITYSIZE) //(r - p + 1) � o n�mero de elementos do subvetor.
        {
            //r�tulo "merge_sort_interno:"
            merge_sort(A, p, q);
            merge_sort(A, q+1, r);
        }
        //r�tulo "merge_sort_procedMerge:"
        merge(A, p, q, r);
    }
//r�tulo "merge_sort_fim:"
}

void merge(int *A, int p, int q, int r)
{
    //r�tulo "merge:"
    int n1, n2, i, j, k, sizeV;

    n1 = q - p + 1;
    n2 = r - q;

    if((r - p + 1) > UNITYSIZE)
    {
        //r�tulo "merge_padrao:"

        for(i = 0; i < n1; i++)
            //r�tulo "merge_padrao_loop1:"
            L[i] = A[p+(i+1)-1];

        //r�tulo "merge_padrao_loop2Inicio:"
        for(j = 0; j < n2; j++)
            //r�tulo "merge_padrao_loop2:"
            R[j] = A[q+(j+1)];

        //r�tulo "merge_padrao_loop2Fim:"
        L[n1] = 0x7fffffff;
        R[n2] = 0x7fffffff;

        for(i=0,j=0,k=p; k <= r; k++)
        {
            //r�tulo "merge_padrao_loop3:"
            if(L[i] <= R[j])
            {
                //r�tulo "merge_padrao_loop3Cond1:"
                A[k] = L[i];
                i++;
            }
            else
            {
                //r�tulo "merge_padrao_loop3Cond2:"
                A[k] = R[j];
                j++;
            }
        }
    }
    else //se (r-p+1)<= UNITYSIZE
    {
        //r�tulo "merge_BubbleSort:"
        sizeV = n1 + n2;

        for(i = 0, j = p; i < sizeV; i++, j++)
            //r�tulo "merge_BubbleSort_loop1:"
            v[i] = A[j];

        //r�tulo "merge_BubbleSort_loop1Fim:"
        bubble_sort(v, sizeV);

        for(i = 0, j = p; i < sizeV; i++, j++)
            //r�tulo "merge_BubbleSort_loop2:"
            A[j] = v[i];
    }
//r�tulo "merge_fim:"
}

void swap(int *v, int i, int j) //troca v[i] por v[j] e vice-versa.
{
    //r�tulo "swap:"
    int aux;

    aux = v[i];
    v[i] = v[j];
    v[j] = aux;
}

void bubble_sort(int *v, int n)
{
    //r�tulo bubble_sort:
    int houveTroca = 1; //uma vari�vel de controle
    int i;

    //r�tulo "bubble_sort_loop:"
    while(houveTroca)
    {

        houveTroca = 0;
        for(i = 0; i < (n-1); i++)
        {
            //r�tulo "bubble_sort_loopInterno:"
            if(v[i] > v[i+1])
            {
                //r�tulo "bubble_sort_procSwap:"
                swap(v, i, i+1);
                houveTroca = 1;
            }
        }
    }
    //r�tulo "bubble_sort_loopFim:"
}
